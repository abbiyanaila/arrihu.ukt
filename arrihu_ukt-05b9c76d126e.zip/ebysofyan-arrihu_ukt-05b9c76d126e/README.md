##Cara Instalasi
1. Buat Environment (Bisa pake **virtualenv** atau pake **anaconda**)
2. Masuk Environment
3. Masuk ke folder web melalui terminal (`cd web/`)
4. Install requirements.txt menggunakan pip (`pip install -r requirements.txt`)
5. Okehh setelah itu lakukan `makemigrations` dan `migrate`
6. Instalasi Django aman
7. Kemudian lakukan install bower components menggunakan `bower install`
8. Nanti disuruh milih2 versi jquery dsb, pkoknya pilih yang required by AdminLTE
9. Jalankan deh (`./manage.py runserver`)