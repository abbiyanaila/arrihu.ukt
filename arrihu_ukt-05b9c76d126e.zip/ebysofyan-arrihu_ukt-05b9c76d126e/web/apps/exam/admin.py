from django.contrib import admin
from apps.exam.models import AssesmentWeight
# Register your models here.

admin.site.register(AssesmentWeight)
