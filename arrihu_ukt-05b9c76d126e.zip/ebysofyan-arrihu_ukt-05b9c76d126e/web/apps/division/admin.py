from django.contrib import admin
from apps.member.models import Division, Level
# Register your models here.

admin.site.register(Division)
admin.site.register(Level)
