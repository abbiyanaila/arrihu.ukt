from django.apps import AppConfig


class DivisionConfig(AppConfig):
    name = 'division'
