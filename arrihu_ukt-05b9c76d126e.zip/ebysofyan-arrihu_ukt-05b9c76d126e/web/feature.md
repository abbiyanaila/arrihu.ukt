+ Dashboard
+ Member
    + Tambah (fix)
    + Ubah (fix)
    + Hapus (fix)
    + Cari (fix)
    + Generate QRCode (fix)

+ Organisasi
    + Tambah (fix)
    + Ubah (fix)
    + Hapus (fix)
    + Cari (fix)

+ Divisi
    + Tambah (fix)
    + Ubah (fix)
    + Hapus (fix)

+ Level
    + Tambah
    + Ubah
    + Hapus

+ Latihan
+ Ujian

+ Rest API
