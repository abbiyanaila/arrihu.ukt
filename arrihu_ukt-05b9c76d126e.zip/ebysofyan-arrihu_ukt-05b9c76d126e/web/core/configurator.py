
from .models import Setting

class Configurator:
    
    @staticmethod
    def set_property(self, config):
        pass
    